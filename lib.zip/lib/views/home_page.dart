import 'package:dummy_project/utils/app_assets.dart';
import 'package:dummy_project/utils/constants.dart';
import 'package:dummy_project/widgets/cusotm_widget.dart';
import 'package:dummy_project/widgets/custom_post.dart';
import 'package:flutter/material.dart';

import '../models/post.dart';
import 'notes_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Post> posts = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(child: Column(
        children: [
          CustomWidget(
            onTap: (val) {
              print('output: $val');
            },
          ),
          CustomWidget(
            onTap: (val) {
              print('output: $val');
            },
          ),
        ],
      ))),
      //   child: Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: ListView.separated(
      //           itemCount: posts.length,
      //           itemBuilder: (context, index) {
      //             return GestureDetector(
      //                 onTap: ()async{
      //                   var result  = await Navigator.push(
      //                       context, MaterialPageRoute(builder: (context) => NotesScreen(text: posts[index].name,)));
      //                if(result!=null){
      //                  setState(() {
      //                    posts[index] = Post(name: result);
      //                  });
      //                }
      //                 },
      //                 child: Text(posts[index].name,style: TextStyle(fontSize: 25),));
      //             // return CustomPostWidget(
      //             //   post: posts[index],
      //             // );
      //           },
      //           separatorBuilder: (context, index) {
      //             return const Divider(
      //               color: Colors.black,
      //               thickness: 2,
      //             );
      //           })),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          var result = await Navigator.push(
              context, MaterialPageRoute(builder: (context) => NotesScreen()));
          print(result);
          if (result != null) {
            setState(() {
              posts.add(Post(name: result));
            });
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
