class Post {
  String name;

  Post({required this.name});
}
