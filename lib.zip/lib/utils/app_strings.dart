class AppStrings{
  static const String login = "Login";
  static const String email = "Email";
  static const String emailHint = "Enter your email here";
  static const String password = "Password";
  static const String passwordHint = "Enter your password here";
}