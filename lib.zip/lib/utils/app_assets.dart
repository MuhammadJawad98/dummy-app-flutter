class AppAssets{
  static const String likeImage ='assets/images/like.png';
  static const String smileImage ='assets/images/smile.png';
  static const String thumbImage ='assets/images/thumbs-up.png';
}