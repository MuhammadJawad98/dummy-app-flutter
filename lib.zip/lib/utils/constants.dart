class Constants{
  static const String dummyImage = 'https://images.unsplash.com/photo-1658801956904-43841e89d831?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8a2lkc3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60';
}